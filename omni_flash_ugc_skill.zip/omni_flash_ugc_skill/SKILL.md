---
name: omni-flash-ugc
version: 1.0.0
description: Session-proven workflow for generating high-quality TikTok/Reels-style UGC with Omni Flash using strict camera ontology, 10-second clip architecture, last-frame continuation, frame-first/photo-to-clip workflows, natural performance, product/UI continuity, and credit-efficient test-to-final iteration.
---

# Omni Flash UGC Skill

This skill is the operating system for producing **high-quality, believable, TikTok-native UGC videos with Omni Flash**.

It is built around the most reliable workflow discovered through repeated generation tests:

**define the physical camera first -> keep the story simple -> generate in <=10 second clips -> preserve continuity with the previous last frame when needed -> use frame-first/photo-to-clip when composition matters more than continuous motion -> test cheaply -> only upscale winners.**

The goal is not to make a beautiful advertisement. The goal is to make footage that feels like **a surprisingly good TikTok someone actually recorded**, while still preserving premium image quality, character consistency, product clarity, and usable continuity.

---

# 1. Scope

Use this skill when the user asks for:

- Omni Flash video prompts
- TikTok / Reels / Shorts UGC
- 10-second or multi-clip ads
- character-based creator content
- product demos that should feel native rather than commercial
- Lokmia UGC
- app-in-phone scenes
- selfie videos
- friend-filmed videos
- fixed-phone videos
- last-frame continuation
- photo-to-clip / frame-first storyboards
- multi-character reaction videos
- food creator videos
- lifestyle creator videos
- multi-phone scenes

This skill is optimized for **short vertical social video**, especially 9:16.

---

# 2. Non-negotiable model rules

## 2.1 Maximum clip length

Treat **10 seconds as the maximum generation length per Omni Flash clip**.

Never write a 20- or 30-second generation as one continuous Omni Flash call.

Instead:

- 20 seconds -> usually 2 x <=10 second clips
- 30 seconds -> usually 3 x <=10 second clips
- longer stories -> additional clips

Each clip must have its own clean purpose.

## 2.2 Default resolution strategy

Use two production modes:

### Draft / creative test
Use **360p** when the user is testing:

- hook
- acting
- motion
- dialogue timing
- camera behavior
- continuity
- story concept

Instruction:

> Generate in 360p draft/test quality. Prioritize performance, motion, timing, camera realism, continuity and creative execution over final visual fidelity.

### Winner / publishable test
Use **720p** when the user wants a stronger final test or publishable version.

Do not spend high-resolution credits on an unproven creative when 360p can answer the creative question.

---

# 3. The central principle

## PREMIUM SENSOR + IMPERFECT HUMAN OPERATOR

The best UGC result is neither cinematic nor low quality.

The target is:

> **The footage should look expensive in IMAGE QUALITY but ordinary in HOW IT WAS FILMED.**

Image quality can be excellent:

- modern flagship smartphone detail
- realistic skin
- believable dynamic range
- clean shadows
- controlled highlights
- crisp food detail
- natural color

But camera operation should remain human:

- small wrist tremor
- slight drift
- imperfect framing
- late reframing
- normal autofocus changes
- minor exposure adaptation
- natural walking bounce
- framing that is not perfectly centered at all times

Avoid the two common failure modes:

1. **cinematic commercial** - too smooth, too perfect, too staged
2. **fake amateur** - excessive shake, ugly image quality, fake noise, intentional sloppiness

UGC realism comes from **behavior**, not from destroying image quality.

---

# 4. Choose the workflow before writing the prompt

There are two main production systems.

## A. Last-Frame Continuation

Use when:

- one physical scene continues over multiple clips
- dialogue continues
- the same camera operator remains in the same position
- one person hands another person an object
- a reaction continues
- a user walks from one nearby action into another
- a phone remains in someone’s hand
- continuous spatial logic matters

Example:

Clip 1 -> user scans food -> turns toward boyfriend -> END

Export last frame.

Clip 2 -> starts from that exact physical moment -> scans boyfriend -> boyfriend says “You’re next.” -> END

Export last frame.

Clip 3 -> phone handoff completes -> boyfriend scans original filmer.

### Core continuation instruction

Always include:

> Continue directly from the exact physical moment shown in the provided starting frame. Do not recreate, redesign, re-stage or reinterpret the scene.

Then explicitly preserve:

- character identity
- wardrobe
- hair
- pose
- hand positions
- prop positions
- visible phone roles
- environment
- lighting
- camera height
- camera direction
- camera perspective
- emotional state

## B. Frame-First / Photo-to-Clip

Use when:

- food is the hero
- different camera angles are desirable
- composition matters more than continuous physical motion
- creator content needs visually perfect anchor shots
- identity consistency is easier to control with stills
- a cooking process jumps between preparation states
- the user wants premium lifestyle shots

Workflow:

1. Write the full story.
2. Split it into shot beats.
3. Generate one anchor frame per shot.
4. Verify identity, wardrobe, environment, objects and food state.
5. Animate each anchor frame into a short clip.
6. Join with natural jump cuts.

Core principle:

> **Build the visual world first. Then animate it.**

Do not force last-frame continuity across intentionally different camera angles.

---

# 5. Prompt architecture

Write prompts in the following order whenever possible:

1. FORMAT / PURPOSE
2. CHARACTER / IDENTITY LOCK
3. CAMERA ONTOLOGY
4. CAMERA BEHAVIOR
5. IMAGE QUALITY
6. SETTING / ENVIRONMENT
7. AMBIENT AUDIO
8. PERFORMANCE / HUMAN BEHAVIOR
9. TIMELINE / STORY BEATS
10. DIALOGUE
11. PRODUCT / UI
12. PHYSICAL CONTINUITY
13. HANDOFF / LAST FRAME
14. RESTRICTIONS
15. FINAL FEELING

This order matters.

Do not begin by describing visual style before deciding **where the viewer physically exists**.

---

# 6. Camera ontology: define physical reality first

This is one of the strongest discoveries in the workflow.

A vague instruction like “she is filming herself with an iPhone” can produce:

- a visible recording phone
- a third-person shot
- an invisible extra camera
- impossible camera geometry

Always define **camera ontology**: where the viewer physically is.

## 6.1 Selfie camera module

Use wording like:

> The entire rendered video IS the live output captured by a modern smartphone front-facing camera. The viewer physically occupies the exact position of the front-camera sensor. This is NOT a third-person shot of someone taking a selfie. The recording device itself can never appear because the viewer is looking THROUGH that device.

Good for:

- direct-to-camera hooks
- walking selfie
- creator confession
- reaction UGC

Natural behavior:

- subtle wrist tremor
- tiny framing adjustments
- occasional face partly off-center
- natural arm movement
- real walking bounce if moving

## 6.2 Friend-filmed module

Use wording like:

> The entire rendered video IS the live image captured by a flagship smartphone held by another person. The viewer physically occupies that smartphone camera sensor. The filming person remains outside the visible frame unless explicitly requested. There is no invisible third camera.

Good for:

- food creator
- couple comedy
- friend reactions
- apartment/kitchen UGC
- gym content

Add:

- 0.2-0.5 second operator reaction latency
- slightly late reframing
- small imperfect corrections
- occasional partial edge framing

The operator should not magically anticipate every movement.

## 6.3 Fixed-phone module

Use wording like:

> The entire rendered video IS the live image from one stationary smartphone camera at the specified height and direction. The physical recording device is completely outside the visible image and must never appear.

CRITICAL:

Do **not** describe how the recording phone is physically supported.

Avoid:

- “phone propped against a mug”
- “phone leaning against a bottle”
- “phone on a stack of books”

These descriptions can cause Omni Flash to render the recording phone inside the shot.

Describe only:

- sensor height
- direction
- distance
- approximate framing

The support method is irrelevant and should remain offscreen.

---

# 7. Multi-phone logic

When two phones exist, assign roles explicitly.

Example:

- **Phone A** = recording phone. Viewer occupies its sensor. It never appears.
- **Phone B** = visible physical phone running Lokmia.

State:

> There are exactly TWO phones involved in the scene. The recording phone is never visible. Exactly ONE other physical phone may appear in frame.

If Phone B changes hands, describe the physical handoff.

Do not let Omni Flash:

- duplicate the phone
- teleport the phone
- swap the recording phone and app phone
- display the app on an impossible screen direction

### Rear-camera physical rule

If Person B points the visible app phone’s rear camera toward the original filmer, the phone screen faces Person B, not the viewer.

Never require both the rear camera and screen to face the viewer simultaneously.

If the exact screen result matters, either:

- cut to a separate readable phone shot, or
- let the character read the result aloud, or
- replace the phone screen in post.

---

# 8. Camera behavior library

Default natural smartphone behavior:

- subtle wrist tremor
- slight horizontal drift
- slight vertical drift
- tiny natural roll
- imperfect reframing
- operator latency
- natural inertia
- mild movement from laughter
- realistic walking bounce
- natural autofocus
- subtle auto-exposure adaptation

Avoid unless specifically requested:

- gimbal smoothness
- dolly movement
- crane movement
- orbit shots
- impossible tracking
- dramatic rack focus
- cinematic push-ins
- deliberate shaky-cam
- fake documentary shake

Never solve “amateur” by making footage visually bad.

---

# 9. Focus and exposure

Use natural smartphone behavior.

Good:

- small face-to-food focus transition
- subtle focus change when phone enters foreground
- slightly delayed refocus
- exposure adaptation when fridge opens
- exposure adjustment when moving near a window
- realistic highlight rolloff

Avoid:

- artificial portrait blur
- extreme bokeh
- dramatic cinematic rack focus
- background becoming an unrecognizable blur

The environment should remain readable enough to feel real.

---

# 10. Environment realism

A believable environment is more valuable than an expensive-looking environment.

Use **lived-in asymmetry**.

Kitchen examples:

- one mug on counter
- dish towel
- partly opened food package
- slightly uneven pantry shelf density
- one used cutting board
- normal small appliances
- half-used container
- fridge magnets where appropriate
- imperfect vegetable shapes
- groceries with normal packaging

Avoid generic AI luxury interiors unless the creator persona specifically requires them.

The environment should communicate:

> **someone actually lives here.**

---

# 11. Quiet-but-alive audio

UGC should not sound acoustically empty.

Use subtle irregular background sound appropriate to the scene:

Kitchen:

- fridge hum
- utensil contact
- cloth movement
- dishes
- pan sizzle
- footsteps

Apartment:

- distant traffic
- muffled neighbor sound
- HVAC
- floor movement

Outdoor:

- birds
- leaves
- occasional passing car
- distant neighborhood activity

Gym:

- occasional weight clank
- distant people
- HVAC
- shoe contact

Rules:

- do not use every sound simultaneously
- keep sounds irregular
- dialogue remains dominant
- avoid stock-SFX feeling
- avoid cinematic whooshes

Music is optional and usually better added later unless the concept depends on it.

---

# 12. Human performance: observed, not performed

A high-quality render can still fail if acting feels fake.

Default acting principle:

> **The character should feel observed rather than performed.**

Use:

- natural blinking
- breathing
- small pauses
- incomplete eye contact
- looking at the task while speaking
- small eyebrow movement
- tiny side-eye
- brief half-smile
- looking back at food to confirm something
- overlapping laughter
- micro hesitation

Avoid:

- reaction after every sentence
- constant direct eye contact
- influencer smile throughout
- presenter voice
- commercial confidence pose
- dramatic eyebrow acting
- scripted punchline performance

### Attention distribution

For most UGC:

- **70-80%** attention toward task / environment / phone / food / partner
- **20-30%** toward camera

This single rule greatly improves realism.

---

# 13. Dialogue rules

Keep dialogue short enough to fit naturally.

A 10-second clip should not contain a paragraph.

Use conversational speech:

- contractions
- short phrases
- interruptions
- half sentences
- pauses

If exact wording matters, add:

> Do not add dialogue that was not explicitly written.

If naturalism matters more than exact copy, define intent instead of over-scripting every syllable.

Avoid advertising phrases unless explicitly requested:

- “You need this app.”
- “Download now.”
- “Best app ever.”
- “This changed my life.”

Better:

- “Wait, that actually works.”
- “Okay… that’s useful.”
- “I did not know it could do that.”

---

# 14. Timeline writing for 10-second clips

Use timecoded beats.

Example:

```json
"timeline": [
  {
    "time": "0.0-2.5s",
    "action": "One clear action.",
    "dialogue": "One short line."
  },
  {
    "time": "2.5-6.0s",
    "action": "Second clear action.",
    "dialogue": "Short reaction."
  },
  {
    "time": "6.0-9.2s",
    "action": "Payoff or setup for next clip.",
    "dialogue": "Optional final line."
  },
  {
    "time": "9.2-10.0s",
    "action": "Reduce movement and create a clean handoff frame."
  }
]
```

## One-primary-action rule

Do not cram:

- walk
- scan phone
- turn screen
- cook
- react
- plate food

into two seconds.

Each beat should have **one primary physical action**.

If the action cannot plausibly happen in the allotted time, move it into the next clip.

---

# 15. Designing the final frame for continuation

The last **0.5-0.8 seconds** of a continuation clip are production infrastructure.

Do not waste them on chaotic movement.

Near the end:

- reduce motion
- keep hands visible
- keep props readable
- keep face/body readable
- avoid motion blur
- avoid occlusion
- preserve environment geometry
- keep phone orientation readable

Use instruction:

> During the final 0.6-0.8 seconds, reduce movement and create a clean, readable continuation frame. Preserve character pose, hand positions, visible props, camera perspective and environment geometry.

This frame becomes the next clip’s first frame.

---

# 16. Continuation prompt template

Use this structure for Clip 2+.

```json
{
  "clip": 2,
  "duration_seconds": 10,
  "starting_frame": "Use the exact exported final frame from the previous clip.",
  "continuity": {
    "instruction": "Continue directly from the exact physical moment shown in the supplied starting frame. Do not recreate, redesign, re-stage or reinterpret the scene.",
    "preserve": [
      "character identity",
      "wardrobe",
      "hair",
      "pose",
      "hand positions",
      "objects",
      "phone roles",
      "environment",
      "lighting",
      "camera height",
      "camera direction",
      "camera perspective",
      "emotional state"
    ]
  }
}
```

Do not merely say “same scene.” Enumerate the physical invariants that matter.

---

# 17. Photo-to-clip / frame-first template

For food, premium creator, or visually controlled content:

```json
{
  "workflow": {
    "type": "FRAME_FIRST_PHOTO_TO_CLIP",
    "steps": [
      "Write the full story.",
      "Split it into short shots.",
      "Create one anchor frame for each shot.",
      "Verify identity, wardrobe, environment, props and food state.",
      "Animate each approved anchor frame into a short clip.",
      "Assemble with simple natural jump cuts."
    ],
    "rule": "Do not begin animation until anchor frames are visually consistent."
  }
}
```

For cooking, define food states explicitly:

- raw ingredients
- chopped/prepped
- cooking
- nearly finished
- plated

This prevents the meal from mutating into unrelated food.

---

# 18. Identity and reference-image rules

When the user already created a character, keep the identity lock concise.

Good:

> Use the uploaded adult character reference as the exact identity. Preserve the same recognizable face, hair, skin tone, facial structure, overall proportions and wardrobe. Do not redesign the character.

Do not repeatedly over-describe anatomy.

For production stability and moderation reliability, focus descriptions on:

- identity
- face
- hair
- wardrobe
- task
- food
- setting
- actions

Avoid unnecessary body-focused framing or anatomical emphasis.

If clothing in the reference causes model moderation failures, create a separate production-friendly reference while preserving the character’s face, hair, color palette and overall style.

---

# 19. Product and app UI rules

The app should feel like part of the story, not a floating ad layer.

For Lokmia:

> Lokmia exists only on the physical phone screen unless an intentional edit is added later.

Avoid:

- floating holographic UI
- giant app interface covering the scene
- impossible AR panels
- screen magically facing both actor and camera
- product hero pose unless requested

## Critical UI text

Generative video models may distort exact small text.

If exact numbers, labels, nutrition values, compliments, recipe names or interface copy matter:

1. Generate the physical phone interaction.
2. Keep the screen readable and stable.
3. Replace/overlay the actual Lokmia UI in post using a real screenshot or screen recording.

Treat this as the preferred production workflow for high-value final ads.

For creative testing, fictional UI is acceptable if it communicates the concept.

---

# 20. Content first, product second

A strong Lokmia creative should usually follow:

**interesting situation -> relatable problem -> surprising behavior/payoff -> Lokmia naturally solves part of it**

Not:

**Lokmia logo -> list of features -> CTA**

The viewer should first care about:

- the person
- the food
- the relationship joke
- the kitchen problem
- the transformation

Then realize:

> “Wait, the app can do that?”

This is the preferred reaction.

---

# 21. Hook system

In short-form video, the first 1-3 seconds must establish tension, curiosity, surprise or immediate utility.

Use hook families such as:

## Confession
- “I’ve been doing this wrong for months.”
- “I stopped counting this manually.”

## Contradiction
- “I had a full fridge and almost ordered food.”

## Challenge
- “Can this actually make dinner from what I have?”

## Relationship / social twist
- “I scanned our dinner… then I scanned my boyfriend.”

## Unexpected product behavior
- “I was scanning my food when the app did this.”

## Budget shock
- “Twenty-three dollars for delivery? Be serious.”

## Curiosity gap
- “I gave the app everything I had left.”

The hook should be physically happening in the first shot whenever possible, not explained as backstory.

---

# 22. UGC story architecture

For 10 seconds:

**Hook -> proof -> payoff**

For 20 seconds / 2 clips:

**Clip 1:** Hook -> setup -> reveal begins -> handoff frame

**Clip 2:** Continue reveal -> reaction -> payoff -> natural ending

For 30 seconds / 3 clips:

**Clip 1:** Hook + premise

**Clip 2:** escalation / product use / transformation

**Clip 3:** payoff / reaction / memorable end

Do not put the strongest idea in the final seconds only. The first clip must stand on its own as interesting content.

---

# 23. Natural endings

UGC should often end while life continues.

Good endings:

- character still laughing
- character turns away
- hand approaches camera
- person takes another bite
- conversation continues off-camera
- camera drifts slightly
- character walks partially out of frame

Avoid by default:

- centered hero pose
- app logo full-screen
- forced smile at camera
- scripted CTA
- commercial fade-out

Unless the user specifically wants a direct-response ad ending.

---

# 24. Food-specific rules

For food UGC:

- prioritize food physics
- keep ingredient continuity
- avoid plastic shine
- use believable steam
- keep sauce viscosity realistic
- show normal home portions unless concept requires restaurant plating
- do not magically introduce ingredients
- keep cooking transformations plausible

Food camera can be more controlled than dialogue camera, but should still feel smartphone-native.

For premium elegant food creators:

- slower hands
- fewer gestures
- restrained facial expression
- clean food close-ups
- no need for chaotic UGC behavior

For chaotic / expressive creators:

- quick side-eye
- short laugh
- imperfect framing
- faster dialogue

Persona should control performance style.

---

# 25. Character lanes

Do not make every creator behave the same.

Define a lane.

Examples:

### Elegant / stoic creator
- confidence through stillness
- low voice
- minimal expressions
- food is hero

### Expressive / fiery creator
- fast micro-expressions
- side-eye
- eyebrow movement
- playful short reactions

### Wholesome / nature creator
- warm
- grounded
- garden / seasonal food
- task-focused attention

### Relatable / chaotic creator
- slightly messy environment
- faster speech
- overlapping laughter
- imperfect framing

Keep the lane consistent across videos so the account feels like a real person, not a random character generator.

---

# 26. Restrictions that improve output

Useful negative constraints:

- No invisible third camera.
- Do not show the recording phone.
- Do not create extra phones.
- Do not teleport objects.
- Do not redesign the character.
- Do not add dialogue that was not explicitly written.
- No floating app UI.
- No gimbal.
- No cinematic dolly.
- No orbit movement.
- No exaggerated reaction acting.
- No beauty-filter skin.
- No plastic food.
- No commercial end card unless requested.

Do not overload the prompt with hundreds of negatives. Use negatives to block known failure modes.

---

# 27. Debugging matrix

When a generation fails, diagnose the failure type instead of rewriting everything.

## Recording phone appears in frame
Cause:
- camera ontology too vague
- physical support object described

Fix:
- define viewer as camera sensor
- explicitly state recording device cannot appear
- remove description of phone support

## Third-person shot instead of selfie
Cause:
- “filming herself” language

Fix:
- use front-camera ontology module

## Extra phone appears
Cause:
- phone roles not explicit

Fix:
- declare exact number of phones and roles

## Phone teleports between hands
Cause:
- handoff not physically described

Fix:
- reserve 1-2 seconds for handoff and continue from last frame

## App screen unreadable
Cause:
- too much small generated text
- phone moving too quickly

Fix:
- simplify UI
- hold phone more stable
- use real UI replacement in post

## Character looks like an actor in an ad
Cause:
- too much eye contact
- every sentence gets a reaction
- presenter dialogue

Fix:
- 70-80% task attention
- quieter beats
- micro-expression only
- shorten dialogue

## Video feels cinematic
Cause:
- “cinematic”, “film”, “dolly”, “bokeh” vocabulary

Fix:
- premium smartphone sensor + imperfect operator language

## Video looks intentionally low quality
Cause:
- “raw”, “amateur”, “lo-fi” interpreted as bad image

Fix:
- explicitly require flagship-phone fidelity and casual human operation

## Character identity drifts
Cause:
- too much transformation within one generation
- reference not strongly locked

Fix:
- concise identity lock
- use frame-first workflow
- reduce clip complexity

## Food changes between clips
Cause:
- food state not specified

Fix:
- define exact ingredients and state at every shot

## Continuation jumps spatially
Cause:
- next clip asked to recreate scene

Fix:
- exact last-frame continuation instruction
- enumerate physical invariants

## Dialogue sounds robotic
Cause:
- too many words
- formal copy

Fix:
- shorten
- use contractions / pauses
- give emotional intent

## Reaction looks fake
Cause:
- “shocked”, “excited”, “amazed” used broadly

Fix:
- describe exact micro-action: half-beat pause, small eyebrow rise, glance back, short laugh

---

# 28. Pre-generation checklist

Before generating any clip, verify:

- Is the story clear in one sentence?
- Is there only one main purpose for this clip?
- Is the hook visible in the first 1-3 seconds?
- Is camera ontology explicit?
- Is the recording device physically logical?
- Are visible phones counted and assigned roles?
- Is dialogue short enough?
- Does each timeline beat have one primary action?
- Is the actor mostly focused on the task rather than camera?
- Is the environment lived-in rather than staged?
- Is the app UI physically contained to a phone?
- Does the final 0.5-0.8 seconds need to become a continuation frame?
- If yes, is movement reduced?
- Is the resolution appropriate: 360p test or 720p winner?

Do not generate until these are coherent.

---

# 29. Post-generation review checklist

After every clip, check:

## Camera
- correct camera ontology?
- recording phone invisible?
- motion human rather than cinematic?

## Character
- exact identity preserved?
- same wardrobe?
- believable expression?

## Physical continuity
- hands correct?
- props correct?
- number of phones correct?
- no teleporting objects?

## Performance
- natural speech?
- too much camera eye contact?
- overacting?

## Product
- app appears where intended?
- UI readable enough?
- feature understandable without explanation?

## Story
- hook works without context?
- payoff clear?
- does it feel like content before advertising?

## Handoff
- final frame clean enough for next clip?

If one element fails, regenerate the smallest necessary unit rather than rewriting the whole campaign.

---

# 30. Canonical JSON skeleton

Use this as the default structure when writing Omni Flash prompts.

```json
{
  "project": {
    "name": "CREATIVE_ID",
    "clip": 1,
    "duration_seconds": 10,
    "aspect_ratio": "9:16",
    "resolution": "360p or 720p",
    "language": "English or Turkish",
    "style": "TikTok-native UGC"
  },

  "character": {
    "reference": "Use uploaded adult character reference as exact identity.",
    "preserve": [
      "face",
      "hair",
      "skin tone",
      "facial structure",
      "overall proportions",
      "wardrobe"
    ],
    "persona": [],
    "performance": []
  },

  "camera": {
    "mode": "selfie | friend_filmed | fixed_phone",
    "ontology": "Define exactly where the viewer physically is.",
    "behavior": [
      "subtle natural tremor",
      "minor drift",
      "imperfect framing corrections",
      "natural autofocus",
      "subtle exposure adaptation"
    ],
    "avoid": [
      "gimbal",
      "dolly",
      "orbit",
      "fake shaky cam"
    ]
  },

  "image_quality": {
    "principle": "Expensive image quality, ordinary human operation.",
    "requirements": [
      "flagship smartphone fidelity",
      "realistic skin",
      "natural dynamic range",
      "believable environment detail"
    ]
  },

  "setting": {
    "location": "",
    "lived_in_details": []
  },

  "audio": {
    "philosophy": "quiet but alive",
    "sounds": [],
    "music": "none unless required"
  },

  "naturalism": {
    "attention_distribution": "70-80% task/environment, 20-30% camera",
    "rules": [
      "natural blinking",
      "small pauses",
      "no reaction after every line",
      "observed rather than performed"
    ]
  },

  "timeline": [
    {
      "time": "0.0-2.5s",
      "action": "",
      "dialogue": ""
    },
    {
      "time": "2.5-6.0s",
      "action": "",
      "dialogue": ""
    },
    {
      "time": "6.0-9.2s",
      "action": "",
      "dialogue": ""
    },
    {
      "time": "9.2-10.0s",
      "action": "Create a clean readable continuation frame if another clip follows."
    }
  ],

  "product_ui": {
    "rule": "UI exists only on physical device screen unless intentionally composited later."
  },

  "restrictions": [
    "Do not add dialogue that was not written.",
    "Do not create extra devices.",
    "No invisible third camera.",
    "No commercial ending unless requested."
  ],

  "final_feeling": ""
}
```

---

# 31. Canonical last-frame continuation skeleton

```json
{
  "project": {
    "clip": 2,
    "duration_seconds": 10,
    "aspect_ratio": "9:16"
  },

  "starting_frame": "Use the exact exported final frame from Clip 1.",

  "continuity": {
    "instruction": "Continue directly from the exact physical moment shown in the provided starting frame. Do not recreate, redesign, re-stage or reinterpret the scene.",
    "preserve": [
      "character identity",
      "wardrobe",
      "hair",
      "body orientation",
      "hand positions",
      "prop positions",
      "phone roles",
      "lighting",
      "environment geometry",
      "camera height",
      "camera direction",
      "camera perspective",
      "emotional state"
    ]
  },

  "timeline": [
    {
      "time": "0.0-1.0s",
      "action": "Continue the exact unfinished physical action from the starting frame."
    }
  ],

  "handoff": {
    "rule": "If another clip follows, reduce movement during the final 0.6-0.8 seconds and create a clean continuation frame."
  }
}
```

---

# 32. Canonical frame-first skeleton

```json
{
  "workflow": {
    "type": "FRAME_FIRST_PHOTO_TO_CLIP",
    "rule": "Create and approve all anchor frames before animation."
  },

  "anchor_frames": [
    {
      "shot": 1,
      "purpose": "hook",
      "identity": "exact reference character",
      "environment": "",
      "composition": "",
      "food_or_prop_state": ""
    },
    {
      "shot": 2,
      "purpose": "setup",
      "identity": "same character",
      "environment": "same world",
      "composition": "",
      "food_or_prop_state": ""
    }
  ],

  "animation_rules": [
    "Animate only the action needed for each shot.",
    "Do not redesign the anchor frame.",
    "Keep motion simple and physically motivated.",
    "Use natural jump cuts between different angles."
  ]
}
```

---

# 33. Skill response behavior

When using this skill to answer a user:

1. Determine whether the request needs **last-frame continuation** or **frame-first/photo-to-clip**.
2. Respect Omni Flash’s <=10 second clip limit.
3. If the user asks for 20/30 seconds, split the concept into multiple prompts.
4. Use 360p for tests unless the user requests 720p or final quality.
5. Write prompts in structured JSON when requested.
6. Do not over-describe an already-created character; reference and preserve them.
7. If the user says “he” or “she” is enough, do not invent character details.
8. Explicitly define camera ontology.
9. Keep product integration secondary to the content idea.
10. Design the last frame intentionally whenever another clip follows.
11. If exact UI text matters, recommend replacing the generated screen with real UI in post.
12. Prefer simple believable situations over elaborate scripted sketches.
13. Keep acting micro, physical and natural.
14. Use a natural ending unless a direct-response CTA is explicitly requested.

---

# 34. Golden rules summary

If only ten rules can be remembered, remember these:

1. **10 seconds max per Omni Flash clip.**
2. **Define where the viewer physically is before describing style.**
3. **Premium sensor + imperfect human operator.**
4. **One primary physical action per timeline beat.**
5. **Characters spend more attention on the task than the camera.**
6. **Use exact last-frame continuation for continuous scenes.**
7. **Use frame-first/photo-to-clip when composition and identity matter more than continuous motion.**
8. **The final 0.5-0.8 seconds are a continuity handoff when another clip follows.**
9. **Content first, product second.**
10. **Test in 360p; render winners in 720p.**

---

# 35. Final quality bar

A successful Omni Flash UGC output should make the viewer think:

> “This feels like a real person happened to capture a good moment.”

Not:

> “This is a polished AI ad pretending to be UGC.”

The strongest result combines:

**physical camera logic + simple story + believable human behavior + stable identity + clear product moment + controlled continuity + native social pacing.**
